# BMW 330e Anatomy

Static GitHub Pages site for an interactive conceptual 3D anatomy viewer of the BMW 330e F30 (2016).

## Publish with GitHub Pages
1. Upload `index.html` and `README.md` to the repository root.
2. Open **Settings → Pages**.
3. Under **Build and deployment**, choose **Deploy from a branch**.
4. Select branch `main`, folder `/ (root)`, then **Save**.
5. Wait for GitHub Pages to publish. The URL will be:
   `https://artembelov231098-dotcom.github.io/bmw-330e-anatomy/`

## Notes
- Three.js and OrbitControls load from jsDelivr CDN, so the viewer needs an internet connection.
- This is a conceptual educational reconstruction, not OEM CAD geometry or a repair reference.
- The geometry is procedurally generated; it is not a verified 3D scan of BMW components.
